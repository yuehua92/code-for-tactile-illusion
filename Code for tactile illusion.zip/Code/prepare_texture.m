function texture = prepare_texture(imagePath, threshold, darkForeground, maxContactNodes)
%PREPARE_TEXTURE Convert an image to bounded contact nodes for the solver.
    imageReference = char(imagePath);
    imagePath = resolve_tactile_path(imagePath);
    if ~exist(imagePath, 'file')
        error('Texture image does not exist: %s', imagePath);
    end
    validateattributes(threshold, {'numeric'}, {'scalar', '>=', 0, '<=', 1});
    validateattributes(maxContactNodes, {'numeric'}, {'scalar', 'integer', '>=', 25, '<=', 6000});

    [imageData, ~, alpha] = imread(imagePath);
    rgb = image_to_rgb_double(imageData, alpha);
    gray = 0.2989 * rgb(:, :, 1) + 0.5870 * rgb(:, :, 2) + 0.1140 * rgb(:, :, 3);

    contactMask = threshold_mask(gray, threshold, darkForeground);
    originalContactCount = nnz(contactMask);
    if originalContactCount < 3
        error(['The selected image contains too little dark foreground. ', ...
            'Use a high-contrast image with a dark texture on a white background.']);
    end

    resizedGray = gray;
    while nnz(contactMask) > maxContactNodes
        scale = 0.97 * sqrt(maxContactNodes / nnz(contactMask));
        nextRows = max(3, floor(size(resizedGray, 1) * scale));
        nextCols = max(3, floor(size(resizedGray, 2) * scale));
        if nextRows == size(resizedGray, 1) && nextCols == size(resizedGray, 2)
            break;
        end
        resizedGray = imresize(resizedGray, [nextRows, nextCols], 'bicubic');
        contactMask = threshold_mask(resizedGray, threshold, darkForeground);
    end

    if nnz(contactMask) > maxContactNodes
        [rowIndex, colIndex] = find(contactMask);
        keepIndex = round(linspace(1, numel(rowIndex), maxContactNodes));
        limitedMask = false(size(contactMask));
        limitedMask(sub2ind(size(contactMask), rowIndex(keepIndex), colIndex(keepIndex))) = true;
        contactMask = limitedMask;
    end
    if nnz(contactMask) < 3
        error(['The texture is too small after image preparation. ', ...
            'Use a larger dark texture on a white background.']);
    end

    [rows, cols] = size(contactMask);
    deltaX = round(15 / cols, 2);
    deltaY = round(15 / rows, 2);
    if deltaX <= 0 || deltaY <= 0
        error('Texture resolution is too high for the 15 mm contact canvas.');
    end

    [rowIndex, colIndex] = find(contactMask);
    texture.xp = deltaX * (colIndex - 1);
    texture.yp = deltaY * (rows - rowIndex + 1);
    texture.rp = deltaX / 2;
    texture.binaryMatrix = ~contactMask;
    texture.gray = resizedGray;
    texture.imagePath = imageReference;
    texture.threshold = threshold;
    texture.darkForeground = logical(darkForeground);
    texture.originalImageSize = size(gray);
    texture.solverImageSize = size(resizedGray);
    texture.originalContactCount = originalContactCount;
    texture.contactCount = nnz(contactMask);
end

function mask = threshold_mask(gray, threshold, darkForeground)
    if darkForeground
        mask = gray < threshold;
    else
        mask = gray > threshold;
    end
end

function rgb = image_to_rgb_double(imageData, alpha)
    imageDouble = im2double(imageData);
    if ndims(imageDouble) == 2
        rgb = repmat(imageDouble, [1, 1, 3]);
    elseif size(imageDouble, 3) >= 3
        rgb = imageDouble(:, :, 1:3);
    else
        rgb = repmat(imageDouble(:, :, 1), [1, 1, 3]);
    end

    if ~isempty(alpha)
        alphaDouble = im2double(alpha);
        if ndims(alphaDouble) == 2
            alphaDouble = repmat(alphaDouble, [1, 1, 3]);
        end
        rgb = rgb .* alphaDouble + (1 - alphaDouble);
    end
end
