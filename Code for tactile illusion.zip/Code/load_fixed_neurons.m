function [xs, ys, metadata] = load_fixed_neurons(xFile, yFile)
%LOAD_FIXED_NEURONS Load the frozen SA receptor realization used in Figure 1.
    xs = load_first_numeric_vector(xFile);
    ys = load_first_numeric_vector(yFile);

    if numel(xs) ~= numel(ys)
        error('Fixed neuron coordinate files contain different point counts.');
    end
    if isempty(xs) || any(~isfinite(xs)) || any(~isfinite(ys))
        error('Fixed neuron coordinates are empty or contain non-finite values.');
    end

    xs = xs(:);
    ys = ys(:);
    metadata.count = numel(xs);
    metadata.xRangeMm = [min(xs), max(xs)];
    metadata.yRangeMm = [min(ys), max(ys)];
    metadata.sourceX = xFile;
    metadata.sourceY = yFile;
end

function values = load_first_numeric_vector(fileName)
    if ~exist(fileName, 'file')
        error('Required fixed-position file is missing: %s', fileName);
    end
    data = load(fileName);
    names = fieldnames(data);
    values = [];
    for i = 1:numel(names)
        candidate = data.(names{i});
        if isnumeric(candidate) && isvector(candidate)
            values = candidate(:);
            return;
        end
    end
    error('No numeric coordinate vector was found in %s.', fileName);
end
