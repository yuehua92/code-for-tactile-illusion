function runFolder = export_tactile_results(result, outputRoot, progressFcn)
%EXPORT_TACTILE_RESULTS Save MAT, CSV, PNG, and vector PDF outputs.
    if nargin < 3 || isempty(progressFcn)
        progressFcn = @(fraction, message) [];
    end
    if ~exist(outputRoot, 'dir')
        mkdir(outputRoot);
    end
    runFolder = unique_run_folder(outputRoot);
    mkdir(runFolder);

    progressFcn(0.02, 'Saving numerical results...');
    save(fullfile(runFolder, 'results.mat'), 'result', '-v7');
    copy_input_image(resolve_tactile_path(result.inputImagePath), runFolder);
    write_sensor_table(result, fullfile(runFolder, 'sensor_values.csv'));
    write_summary(result, fullfile(runFolder, 'run_summary.txt'));

    types = {'texture', 'skinstrain', 'membranetension', ...
        'channelopen', 'spikeproxy'};
    names = {'texture', 'skin_strain', 'membrane_tension', ...
        'channel_open_percent', 'firing_rate'};
    selected = selected_outputs(result.params.outputs);
    selectedCount = max(1, sum(selected));
    completed = 0;
    for i = 1:numel(types)
        if ~selected(i)
            continue;
        end
        fig = figure('Visible', 'off', 'Color', 'w', 'Units', 'pixels', ...
            'Position', [100 100 600 700]);
        cleaner = onCleanup(@() close_if_valid(fig)); %#ok<NASGU>
        ax = axes('Parent', fig, 'Position', [0.12 0.18 0.76 0.75]);
        plot_tactile_output(ax, result, types{i}, true);
        pngFile = fullfile(runFolder, [names{i}, '.png']);
        pdfFile = fullfile(runFolder, [names{i}, '.pdf']);
        print(fig, pngFile, '-dpng', '-r300');
        configure_pdf(fig);
        print(fig, pdfFile, '-dpdf', '-painters', '-r300');
        close(fig);
        completed = completed + 1;
        progressFcn(0.12 + 0.72 * completed / selectedCount, ...
            sprintf('Exporting %s...', names{i}));
    end

    progressFcn(0.88, 'Building the overview figure...');
    export_overview(result, types, selected, fullfile(runFolder, 'overview.png'));
    progressFcn(1, sprintf('Results saved to %s', runFolder));
end

function folderPath = unique_run_folder(outputRoot)
    baseName = ['run_', datestr(now, 'yyyymmdd_HHMMSS')];
    folderPath = fullfile(outputRoot, baseName);
    suffix = 1;
    while exist(folderPath, 'dir')
        folderPath = fullfile(outputRoot, sprintf('%s_%02d', baseName, suffix));
        suffix = suffix + 1;
    end
end

function selected = selected_outputs(outputs)
    selected = [outputs.texture, outputs.skinStrain, outputs.membraneTension, ...
        outputs.channelOpen, outputs.spikeProxy];
    selected = logical(selected);
end

function write_sensor_table(result, fileName)
    n = numel(result.xs);
    epsilon = column_or_nan(result.rawSensorEpsilon, n);
    tension = column_or_nan(result.membraneTensionPNPerUm, n);
    channel = column_or_nan(result.channelOpenPercent, n);
    spikeDisplay = column_or_nan(result.spikeProxyHz, n);
    sensorTable = table(result.xs(:), result.ys(:), epsilon, tension, channel, ...
        spikeDisplay, 'VariableNames', ...
        {'x_mm', 'y_mm', 'epsilon_zz_raw', 'membrane_tension_pN_per_um', ...
        'channel_open_percent', 'firing_rate_Hz'});
    writetable(sensorTable, fileName);
end

function values = column_or_nan(values, n)
    if isempty(values)
        values = nan(n, 1);
    else
        values = values(:);
    end
end

function write_summary(result, fileName)
    fid = fopen(fileName, 'w');
    if fid < 0
        error('Could not create summary file: %s', fileName);
    end
    cleaner = onCleanup(@() fclose(fid)); %#ok<NASGU>
    fprintf(fid, 'Tactile Neuron Analyzer\n');
    fprintf(fid, 'Created: %s\n', result.createdAt);
    fprintf(fid, 'Input image: %s\n', result.inputImagePath);
    fprintf(fid, 'Display mode: %s\n', result.displayMode);
    fprintf(fid, 'Fixed SA neurons: %d\n', numel(result.xs));
    fprintf(fid, 'Contact nodes: %d\n', result.texture.contactCount);
    fprintf(fid, 'Surface displacement (mm, fixed): %.6g\n', ...
        result.params.surfaceDisplacementMm);
    fprintf(fid, 'Threshold: %.6g\n', result.params.threshold);
    fprintf(fid, 'Skin modulus (Pa): %.6g\n', result.params.skinYoungModulusPa);
    fprintf(fid, 'Neuron depth (mm): %.6g\n', result.params.neuronDepthMm);
    fprintf(fid, 'Cortex modulus (MPa): %.6g\n', result.params.cortexYoungModulusMPa);
    fprintf(fid, 'Cell deformation gain (fixed): %.6g\n', ...
        result.params.cellDeformationGain);
    fprintf(fid, 'Effective strain-to-indentation length (um): %.6g\n', ...
        result.params.cellHeightUm * result.params.cellDeformationGain);
    if ~isempty(result.spikeProxyHz)
        fprintf(fid, ['Firing rate display source: deformation mapping ' ...
            '(200 * abs(raw strain), values below 10 Hz set to zero, clipped at 40 Hz)\n']);
        fprintf(fid, 'Firing rate range (Hz): %.6g to %.6g\n', ...
            min(result.spikeProxyHz), max(result.spikeProxyHz));
    end
    fprintf(fid, 'Compliance reciprocal condition: %.6g\n', ...
        result.mechanicsDiagnostics.reciprocalCondition);
    fprintf(fid, 'Compliance regularization: %.6g\n', ...
        result.mechanicsDiagnostics.regularization);
end

function copy_input_image(sourceFile, runFolder)
    [~, name, extension] = fileparts(sourceFile);
    destination = fullfile(runFolder, ['input_', name, extension]);
    copyfile(sourceFile, destination);
end

function export_overview(result, types, selected, fileName)
    fig = figure('Visible', 'off', 'Color', [0.97 0.98 0.98], ...
        'Units', 'pixels', 'Position', [100 100 1500 900]);
    cleaner = onCleanup(@() close_if_valid(fig)); %#ok<NASGU>
    positions = overview_positions();
    for i = 1:numel(types)
        ax = axes('Parent', fig, 'Position', positions(i, :));
        if selected(i)
            plot_tactile_output(ax, result, types{i}, true);
        else
            axis(ax, 'off');
            text(ax, 0.5, 0.5, 'Not selected', 'Units', 'normalized', ...
                'HorizontalAlignment', 'center', 'Color', [0.45 0.50 0.54], ...
                'FontName', 'Arial', 'FontSize', 11);
        end
    end
    print(fig, fileName, '-dpng', '-r200');
    close(fig);
end

function positions = overview_positions()
    positions = zeros(6, 4);
    left = 0.035;
    gapX = 0.028;
    width = (1 - 2 * left - 2 * gapX) / 3;
    height = 0.39;
    bottoms = [0.55, 0.07];
    k = 1;
    for row = 1:2
        for col = 1:3
            positions(k, :) = [left + (col - 1) * (width + gapX), ...
                bottoms(row), width, height];
            k = k + 1;
        end
    end
end

function configure_pdf(fig)
    set(fig, 'Renderer', 'painters', 'PaperPositionMode', 'auto');
    oldUnits = get(fig, 'Units');
    set(fig, 'Units', 'inches');
    position = get(fig, 'Position');
    set(fig, 'PaperUnits', 'inches', 'PaperPosition', [0 0 position(3) position(4)], ...
        'PaperSize', [position(3) position(4)]);
    set(fig, 'Units', oldUnits);
end

function close_if_valid(fig)
    if ishghandle(fig)
        close(fig);
    end
end
