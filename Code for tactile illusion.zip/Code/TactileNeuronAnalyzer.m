function TactileNeuronAnalyzer(varargin)
%TACTILENEURONANALYZER Desktop entry point for the tactile model.
    rootPath = tactile_app_root();
    if ~isdeployed
        addpath(rootPath);
    end

    if nargin >= 1 && strcmpi(char(varargin{1}), '--selftest')
        if nargin >= 2
            markerFile = char(varargin{2});
        else
            markerFile = fullfile(tempdir, 'TactileNeuronAnalyzer_compiled_selftest.mat');
        end
        verify_package(markerFile);
        return;
    end

    params = runtime_profile();
    screenSize = get(0, 'ScreenSize');
    figureWidth = min(1380, screenSize(3) - 60);
    figureHeight = min(820, screenSize(4) - 100);
    figureLeft = max(20, round((screenSize(3) - figureWidth) / 2));
    figureBottom = max(40, round((screenSize(4) - figureHeight) / 2));

    colors.window = [0.965 0.973 0.973];
    colors.panel = [1 1 1];
    colors.text = [0.08 0.16 0.18];
    colors.muted = [0.35 0.42 0.44];
    colors.border = [0.82 0.85 0.85];
    colors.teal = [0.05 0.58 0.53];
    colors.orange = [0.96 0.40 0.08];

    fig = figure('Name', 'Tactile Neuron Analyzer', 'NumberTitle', 'off', ...
        'MenuBar', 'none', 'ToolBar', 'none', 'Color', colors.window, ...
        'Units', 'pixels', 'Position', [figureLeft figureBottom figureWidth figureHeight], ...
        'Resize', 'off', 'CloseRequestFcn', @close_main_window);

    uicontrol(fig, 'Style', 'text', 'String', 'Tactile Neuron Analyzer', ...
        'Position', [24 figureHeight - 54 420 30], 'BackgroundColor', colors.window, ...
        'ForegroundColor', colors.text, 'HorizontalAlignment', 'left', ...
        'FontName', 'Arial', 'FontSize', 18, 'FontWeight', 'bold');
    uicontrol(fig, 'Style', 'text', 'String', 'Figure 1 electromechanical pipeline', ...
        'Position', [447 figureHeight - 49 310 22], 'BackgroundColor', colors.window, ...
        'ForegroundColor', colors.muted, 'HorizontalAlignment', 'left', ...
        'FontName', 'Arial', 'FontSize', 10);

    panelHeight = figureHeight - 88;
    controlPanel = uipanel(fig, 'Units', 'pixels', 'Position', [18 18 300 panelHeight], ...
        'BackgroundColor', colors.panel, 'BorderType', 'line', ...
        'HighlightColor', colors.border, 'ShadowColor', colors.border);

    handles = create_controls(controlPanel, panelHeight, params, colors);
    [axesHandles, axesPositions] = create_preview_axes(fig, figureWidth, figureHeight, colors);

    state.params = params;
    state.handles = handles;
    state.axes = axesHandles;
    state.axesPositions = axesPositions;
    state.colorbars = cell(1, 5);
    state.result = [];
    state.running = false;
    state.cancelRequested = false;
    state.closeRequested = false;
    state.waitbar = [];
    state.colors = colors;
    guidata(fig, state);
    show_placeholders(fig);
end

function handles = create_controls(parent, panelHeight, params, colors)
    left = 16;
    fieldWidth = 268;
    labelHeight = 18;
    editHeight = 27;
    y = panelHeight - 37;

    make_label(parent, 'Input texture', [left y fieldWidth labelHeight], colors);
    y = y - 32;
    handles.imageBrowse = make_button(parent, 'Choose image', [left y 104 editHeight], ...
        colors.teal, [1 1 1], @browse_image);
    handles.imageName = uicontrol(parent, 'Style', 'text', ...
        'String', display_file_name(params.imagePath), ...
        'Position', [128 y 156 editHeight], 'HorizontalAlignment', 'left', ...
        'FontName', 'Microsoft YaHei UI', 'FontSize', 9, ...
        'BackgroundColor', colors.panel, 'ForegroundColor', colors.text, ...
        'TooltipString', params.imagePath);

    y = y - 42;
    make_section_label(parent, 'Outputs', [left y fieldWidth labelHeight], colors);
    y = y - 29;
    handles.textureCheck = make_check(parent, 'Texture / displacement', params.outputs.texture, [left y 250 22]);
    y = y - 27;
    handles.skinCheck = make_check(parent, 'Skin strain', params.outputs.skinStrain, [left y 250 22]);
    y = y - 27;
    handles.tensionCheck = make_check(parent, 'Membrane tension', params.outputs.membraneTension, [left y 250 22]);
    y = y - 27;
    handles.channelCheck = make_check(parent, 'Channel open percentage', params.outputs.channelOpen, [left y 250 22]);
    y = y - 27;
    handles.proxyCheck = make_check(parent, 'Firing rate (Hz)', params.outputs.spikeProxy, [left y 270 22]);
    set([handles.textureCheck, handles.skinCheck, handles.tensionCheck, ...
        handles.channelCheck, handles.proxyCheck], 'Callback', @output_selection_changed);

    y = y - 47;
    handles.runButton = make_button(parent, 'Run simulation', [left y fieldWidth 34], ...
        colors.orange, [1 1 1], @run_or_cancel);

    handles.statusText = uicontrol(parent, 'Style', 'text', 'String', 'Ready', ...
        'Position', [left 12 fieldWidth 42], 'HorizontalAlignment', 'left', ...
        'BackgroundColor', colors.panel, 'ForegroundColor', colors.muted, ...
        'FontName', 'Microsoft YaHei UI', 'FontSize', 9);

    handles.parameterControls = [handles.imageBrowse, handles.textureCheck, ...
        handles.skinCheck, handles.tensionCheck, handles.channelCheck, ...
        handles.proxyCheck];
end

function [axesHandles, positions] = create_preview_axes(fig, figureWidth, figureHeight, colors)
    mainLeft = 340;
    mainRight = 20;
    mainBottom = 30;
    mainTop = 78;
    gapX = 25;
    gapY = 35;
    totalWidth = figureWidth - mainLeft - mainRight;
    totalHeight = figureHeight - mainBottom - mainTop;
    axesWidth = (totalWidth - 2 * gapX) / 3;
    axesHeight = (totalHeight - gapY) / 2;
    positions = zeros(5, 4);
    axesHandles = gobjects(1, 5);
    index = 1;
    for row = 1:2
        for col = 1:3
            if index > 5
                break;
            end
            x = mainLeft + (col - 1) * (axesWidth + gapX);
            y = mainBottom + (2 - row) * (axesHeight + gapY);
            positions(index, :) = [x y axesWidth axesHeight];
            axesHandles(index) = axes('Parent', fig, 'Units', 'pixels', ...
                'Position', positions(index, :), 'Color', colors.panel, ...
                'Box', 'off', 'FontName', 'Arial');
            index = index + 1;
        end
    end
end

function show_placeholders(fig)
    state = guidata(fig);
    labels = {'Texture', 'Skin deformation', 'Neuron deformation', ...
        'Channel activation', 'Firing rate (Hz)'};
    for i = 1:5
        ax = state.axes(i);
        cla(ax, 'reset');
        set(ax, 'Color', [1 1 1]);
        axis(ax, 'off');
        text(ax, 0.5, 0.53, labels{i}, 'Units', 'normalized', ...
            'HorizontalAlignment', 'center', 'FontName', 'Arial', ...
            'FontSize', 11, 'Color', [0.32 0.39 0.41]);
        text(ax, 0.5, 0.44, 'Not calculated', 'Units', 'normalized', ...
            'HorizontalAlignment', 'center', 'FontName', 'Arial', ...
            'FontSize', 9, 'Color', [0.60 0.64 0.65]);
    end
end

function browse_image(source, ~)
    fig = ancestor(source, 'figure');
    state = guidata(fig);
    startPath = resolve_tactile_path(state.params.imagePath);
    [fileName, folderName] = uigetfile( ...
        {'*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp', 'Image files'; '*.*', 'All files'}, ...
        'Select texture image', startPath);
    if isequal(fileName, 0)
        return;
    end
    fullName = fullfile(folderName, fileName);
    portableName = make_tactile_relative_path(fullName);
    state.params.imagePath = portableName;
    set(state.handles.imageName, 'String', display_file_name(portableName), ...
        'TooltipString', portableName);
    guidata(fig, state);
    invalidate_result(fig, 'Image selected. Run simulation.');
end

function output_selection_changed(source, ~)
    fig = ancestor(source, 'figure');
    state = guidata(fig);
    if isempty(state.result)
        return;
    end
    invalidate_result(fig, 'Output selection changed. Run simulation.');
end

function invalidate_result(fig, statusText)
    state = guidata(fig);
    delete_colorbars(state.colorbars);
    state.colorbars = cell(1, 5);
    state.result = [];
    set(state.handles.statusText, 'String', statusText, 'TooltipString', '');
    guidata(fig, state);
    show_placeholders(fig);
end

function run_or_cancel(source, ~)
    fig = ancestor(source, 'figure');
    state = guidata(fig);
    if state.running
        request_cancel(fig);
        return;
    end

    try
        params = read_params(state.handles, state.params);
    catch parameterError
        errordlg(parameterError.message, 'Invalid parameters', 'modal');
        return;
    end

    state.params = params;
    state.running = true;
    state.cancelRequested = false;
    state.closeRequested = false;
    set(state.handles.parameterControls, 'Enable', 'off');
    set(state.handles.runButton, 'String', 'Cancel after step', ...
        'BackgroundColor', [0.72 0.16 0.12]);
    set(state.handles.statusText, 'String', 'Starting...');
    waitHandle = waitbar(0, 'Starting...', 'Name', 'Tactile Neuron Analyzer', ...
        'CreateCancelBtn', 'setappdata(gcbf,''canceling'',1)');
    setappdata(waitHandle, 'canceling', 0);
    state.waitbar = waitHandle;
    guidata(fig, state);

    try
        progress = @(fraction, message) update_progress(fig, waitHandle, fraction, message);
        cancel = @() is_cancelled(fig, waitHandle);
        result = run_tactile_model(params, progress, cancel);
        render_result(fig, result);
        update_progress(fig, waitHandle, 0.90, 'Exporting selected outputs...');
        runFolder = export_tactile_results(result, params.outputRoot, ...
            @(fraction, message) update_progress(fig, waitHandle, 0.90 + 0.10 * fraction, message));

        state = guidata(fig);
        state.result = result;
        statusText = 'Saved. Simulation complete.';
        set(state.handles.statusText, 'String', statusText, 'TooltipString', runFolder);
        guidata(fig, state);
    catch runError
        if strcmp(runError.identifier, 'TactileNeuronAnalyzer:Cancelled')
            state = guidata(fig);
            set(state.handles.statusText, 'String', 'Cancelled');
        else
            state = guidata(fig);
            set(state.handles.statusText, 'String', 'Simulation failed');
            errordlg(runError.message, 'Simulation failed', 'modal');
        end
    end
    finish_run(fig, waitHandle);
end

function params = read_params(handles, params)
    params.threshold = 0.60;
    params.darkForeground = true;
    params.maxContactNodes = 900;
    params.surfaceDisplacementMm = 2;
    params.cellDeformationGain = 1;
    params.displayMode = 'figure1';
    params.outputs.texture = logical(get(handles.textureCheck, 'Value'));
    params.outputs.skinStrain = logical(get(handles.skinCheck, 'Value'));
    params.outputs.membraneTension = logical(get(handles.tensionCheck, 'Value'));
    params.outputs.channelOpen = logical(get(handles.channelCheck, 'Value'));
    params.outputs.spikeProxy = logical(get(handles.proxyCheck, 'Value'));
    params.outputs.trueFiring = false;

    if ~exist(resolve_tactile_path(params.imagePath), 'file')
        error('Input image does not exist.');
    end
    if isempty(params.outputRoot)
        error('Output folder is required.');
    end
end

function update_progress(fig, waitHandle, fraction, message)
    if ~ishghandle(fig)
        return;
    end
    state = guidata(fig);
    set(state.handles.statusText, 'String', message);
    if ishghandle(waitHandle)
        fraction = min(max(fraction, 0), 1);
        waitbar(fraction, waitHandle, message);
    end
    drawnow;
end

function cancelled = is_cancelled(fig, waitHandle)
    cancelled = ~ishghandle(fig);
    if ~cancelled
        state = guidata(fig);
        cancelled = state.cancelRequested;
    end
    if ~cancelled && ishghandle(waitHandle)
        cancelled = logical(getappdata(waitHandle, 'canceling'));
    end
end

function request_cancel(fig)
    if ~ishghandle(fig)
        return;
    end
    state = guidata(fig);
    state.cancelRequested = true;
    set(state.handles.statusText, 'String', 'Canceling after the current solver step...');
    set(state.handles.runButton, 'Enable', 'off', 'String', 'Canceling...');
    if ishghandle(state.waitbar)
        setappdata(state.waitbar, 'canceling', 1);
    end
    guidata(fig, state);
    drawnow;
end

function finish_run(fig, waitHandle)
    if ishghandle(waitHandle)
        delete(waitHandle);
    end
    if ~ishghandle(fig)
        return;
    end
    state = guidata(fig);
    state.running = false;
    state.waitbar = [];
    set(state.handles.parameterControls, 'Enable', 'on');
    set(state.handles.runButton, 'Enable', 'on', 'String', 'Run simulation', ...
        'BackgroundColor', state.colors.orange);
    guidata(fig, state);
    if state.closeRequested
        delete(fig);
    end
end

function render_result(fig, result)
    state = guidata(fig);
    delete_colorbars(state.colorbars);
    types = {'texture', 'skinstrain', 'membranetension', ...
        'channelopen', 'spikeproxy'};
    selected = [result.params.outputs.texture, result.params.outputs.skinStrain, ...
        result.params.outputs.membraneTension, result.params.outputs.channelOpen, ...
        result.params.outputs.spikeProxy];
    colorbars = cell(1, 5);
    for i = 1:5
        set(state.axes(i), 'Position', state.axesPositions(i, :));
        if selected(i)
            colorbars{i} = plot_tactile_output(state.axes(i), result, types{i}, true);
        else
            cla(state.axes(i), 'reset');
            axis(state.axes(i), 'off');
            text(state.axes(i), 0.5, 0.5, 'Not selected', 'Units', 'normalized', ...
                'HorizontalAlignment', 'center', 'FontName', 'Arial', ...
                'Color', [0.55 0.59 0.60]);
        end
    end
    state.result = result;
    state.colorbars = colorbars;
    guidata(fig, state);
    drawnow;
end

function delete_colorbars(colorbars)
    for i = 1:numel(colorbars)
        if ~isempty(colorbars{i}) && ishghandle(colorbars{i})
            delete(colorbars{i});
        end
    end
end

function close_main_window(source, ~)
    state = guidata(source);
    if state.running
        state.closeRequested = true;
        guidata(source, state);
        request_cancel(source);
    else
        delete(source);
    end
end

function handle = make_label(parent, textValue, position, colors)
    handle = uicontrol(parent, 'Style', 'text', 'String', textValue, ...
        'Position', position, 'HorizontalAlignment', 'left', ...
        'BackgroundColor', colors.panel, 'ForegroundColor', colors.text, ...
        'FontName', 'Arial', 'FontSize', 9);
end

function handle = make_section_label(parent, textValue, position, colors)
    handle = uicontrol(parent, 'Style', 'text', 'String', textValue, ...
        'Position', position, 'HorizontalAlignment', 'left', ...
        'BackgroundColor', colors.panel, 'ForegroundColor', colors.text, ...
        'FontName', 'Arial', 'FontSize', 10, 'FontWeight', 'bold');
end

function handle = make_check(parent, textValue, initialValue, position)
    handle = uicontrol(parent, 'Style', 'checkbox', 'String', textValue, ...
        'Value', initialValue, 'Position', position, 'BackgroundColor', [1 1 1], ...
        'ForegroundColor', [0.08 0.16 0.18], 'FontName', 'Arial', 'FontSize', 9);
end

function fileName = display_file_name(filePath)
    [~, name, extension] = fileparts(filePath);
    fileName = [name, extension];
end

function handle = make_button(parent, textValue, position, backgroundColor, foregroundColor, callback)
    handle = uicontrol(parent, 'Style', 'pushbutton', 'String', textValue, ...
        'Position', position, 'BackgroundColor', backgroundColor, ...
        'ForegroundColor', foregroundColor, 'FontName', 'Arial', ...
        'FontSize', 9, 'FontWeight', 'bold', 'Callback', callback);
end
