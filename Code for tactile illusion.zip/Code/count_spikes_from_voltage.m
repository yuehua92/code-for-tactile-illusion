function [firingRateHz, spikeCount] = count_spikes_from_voltage(timeMs, voltageMv, windowStartMs, windowEndMs, thresholdMv)
%COUNT_SPIKES_FROM_VOLTAGE Count upward threshold crossings in a time window.
    timeMs = timeMs(:);
    voltageMv = voltageMv(:);
    if numel(timeMs) ~= numel(voltageMv) || numel(timeMs) < 2
        error('Time and voltage must be vectors of equal length with at least two samples.');
    end
    if windowEndMs <= windowStartMs
        error('Spike-counting window must have positive duration.');
    end

    crossing = voltageMv(2:end) > thresholdMv & voltageMv(1:end-1) <= thresholdMv;
    crossingTimes = timeMs(2:end);
    inWindow = crossingTimes >= windowStartMs & crossingTimes < windowEndMs;
    spikeCount = sum(crossing & inWindow);
    firingRateHz = spikeCount / ((windowEndMs - windowStartMs) / 1000);
end
