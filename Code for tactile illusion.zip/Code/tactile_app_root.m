function rootPath = tactile_app_root()
%TACTILE_APP_ROOT Return the resource root in MATLAB and deployed modes.
    functionRoot = fileparts(mfilename('fullpath'));
    candidates = {functionRoot};
    if isdeployed
        candidates{end + 1} = fullfile(ctfroot, 'TactileNeuro');
        candidates{end + 1} = ctfroot;
    end
    for i = 1:numel(candidates)
        if exist(fullfile(candidates{i}, 'assets', 'layout_x.mat'), 'file')
            rootPath = candidates{i};
            return;
        end
    end
    error('Could not locate packaged application assets.');
end
