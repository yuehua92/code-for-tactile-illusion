function resolvedPath = resolve_tactile_path(filePath)
%RESOLVE_TACTILE_PATH Resolve packaged relative resources at runtime.
    filePath = char(filePath);
    if is_absolute_path(filePath)
        resolvedPath = filePath;
    else
        resolvedPath = fullfile(tactile_app_root(), filePath);
    end
end

function absolute = is_absolute_path(filePath)
    absolute = ~isempty(regexp(filePath, '^[A-Za-z]:[\\/]|^\\\\|^/', 'once'));
end
