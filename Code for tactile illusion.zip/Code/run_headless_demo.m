function runFolder = run_headless_demo()
%RUN_HEADLESS_DEMO Run a small deterministic example without the GUI.
    rootPath = tactile_app_root();
    addpath(rootPath);
    params = runtime_profile();
    params.maxContactNodes = 300;
    params.gridNx = 55;
    params.gridNy = 82;
    params.outputs.trueFiring = false;
    result = run_tactile_model(params, @print_progress, @() false);
    runFolder = export_tactile_results(result, params.outputRoot, @print_progress);
    fprintf('Demo output: %s\n', runFolder);
end

function print_progress(fraction, message)
    fprintf('%3.0f%%  %s\n', 100 * fraction, message);
end
