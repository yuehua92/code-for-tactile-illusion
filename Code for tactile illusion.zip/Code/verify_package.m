function report = verify_package(markerFile)
%VERIFY_PACKAGE Verify deployed assets and core toolbox components.
    params = runtime_profile();
    params.maxContactNodes = 80;
    params.gridNx = 24;
    params.gridNy = 36;
    params.outputs.texture = false;
    params.outputs.skinStrain = true;
    params.outputs.membraneTension = true;
    params.outputs.channelOpen = true;
    params.outputs.spikeProxy = false;
    params.outputs.trueFiring = false;
    result = run_tactile_model(params, @(fraction, message) [], @() false);

    assert(params.surfaceDisplacementMm == 2 && params.cellDeformationGain == 1, ...
        'Compiled desktop condition is not fixed at u0=2 mm and gain=1x.');
    assert(numel(result.xs) == 1880, 'Compiled fixed-position asset check failed.');
    assert(result.texture.contactCount <= params.maxContactNodes, ...
        'Compiled texture preprocessing check failed.');
    assert(all(isfinite(result.membraneTensionPNPerUm)), ...
        'Compiled mechanics check returned non-finite values.');
    assert(all(isfinite(result.channelOpenPercent)), ...
        'Compiled channel mapping returned non-finite values.');
    assert(all(result.spikeProxyHz >= 0 & result.spikeProxyHz <= 40), ...
        'Compiled firing-rate display is outside 0-40 Hz.');

    lookupParams = runtime_profile();
    lookupParams.trueSpikeWindowMs = 100;
    lookupParams.odeStepMs = 0.1;
    lookupParams.cortexYoungModulusMPa = 6e-3;
    lookupParams.voltageThresholdMv = 10;
    lookupParams.useFiringLookup = true;
    assert(exist(lookupParams.firingLookupFile, 'file') == 2, ...
        'Compiled 100 ms HH firing lookup asset is missing.');
    lookupNeeds.membraneTension = false;
    lookupNeeds.channelOpen = false;
    lookupNeeds.trueFiring = true;
    lookupEpsilon = -0.60 * ones(numel(result.xs), 1);
    lookupSimulation = simulate_neuron_response(lookupEpsilon, lookupParams, ...
        lookupNeeds, @(fraction, message) [], @() false);
    assert(strcmp(lookupSimulation.firingSource, ...
        'HH response lookup (100 ms; threshold crossings)'), ...
        'Compiled 100 ms true-firing calculation did not use the packaged lookup.');
    assert(lookupSimulation.holdDurationMs == 100, ...
        'Compiled firing lookup used an unexpected observation window.');
    assert(numel(lookupSimulation.trueFiringRateHz) == numel(result.xs) && ...
        numel(lookupSimulation.spikeCount) == numel(result.xs), ...
        'Compiled firing lookup returned the wrong neuron count.');
    assert(all(isfinite(lookupSimulation.trueFiringRateHz)) && ...
        all(lookupSimulation.trueFiringRateHz >= 0), ...
        'Compiled firing lookup returned invalid rates.');
    assert(any(lookupSimulation.spikeCount > 0), ...
        'Compiled firing lookup did not produce a spike at the smoke-test deformation.');

    params.trueSpikeWindowMs = 10;
    needs.membraneTension = true;
    needs.channelOpen = true;
    needs.trueFiring = true;
    simulation = simulate_neuron_response(-0.50, params, needs, ...
        @(fraction, message) [], @() false);
    assert(simulation.spikeCount >= 1, ...
        'Compiled HH model did not generate the expected threshold crossing.');
    assert(strcmp(simulation.firingSource, 'Direct HH voltage threshold crossings'), ...
        'Compiled 10 ms test did not exercise direct HH threshold counting.');

    report.passed = true;
    report.createdAt = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    report.fixedNeuronCount = numel(result.xs);
    report.contactNodeCount = result.texture.contactCount;
    report.lookupNeuronCount = numel(lookupSimulation.trueFiringRateHz);
    report.lookupActiveNeuronCount = nnz(lookupSimulation.spikeCount > 0);
    report.lookupFiringRateHz = lookupSimulation.trueFiringRateHz(1);
    report.hhSpikeCount = simulation.spikeCount;
    report.hhFiringRateHz = simulation.trueFiringRateHz;
    report.isDeployed = isdeployed;
    save(markerFile, 'report');
end
