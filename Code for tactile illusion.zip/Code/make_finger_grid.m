function [X, Y, fingerMask] = make_finger_grid(nx, ny)
%MAKE_FINGER_GRID Create the 15 mm by 22.5 mm Figure 1 finger-pad domain.
    xGrid = linspace(0, 15, nx);
    yGrid = linspace(0, 22.5, ny);
    [X, Y] = meshgrid(xGrid, yGrid);
    fingerMask = (Y <= 15 & X >= 0 & X <= 15) | ...
        (Y > 15 & ((X - 7.5) .^ 2 + (Y - 15) .^ 2 <= 7.5 ^ 2));
end
