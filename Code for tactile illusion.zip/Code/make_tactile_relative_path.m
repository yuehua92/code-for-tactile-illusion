function portablePath = make_tactile_relative_path(filePath)
%MAKE_TACTILE_RELATIVE_PATH Keep bundled assets portable in saved state.
    filePath = char(filePath);
    rootPath = tactile_app_root();
    rootPrefix = [rootPath, filesep];
    if strncmpi(filePath, rootPrefix, numel(rootPrefix))
        portablePath = filePath(numel(rootPrefix) + 1:end);
    else
        portablePath = filePath;
    end
end
